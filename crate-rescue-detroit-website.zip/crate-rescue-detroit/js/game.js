/*
  Crate Rescue: Detroit - the game.
  Hidden surplus crates pile up in six real Detroit construction yards. A drone scans
  them, a built-in AI dispatcher proposes truck trips, and the city refuses trips that
  can't work. Tweak the numbers in the first lines below to change how the game plays.
*/
(function () {
"use strict";
const $ = id => document.getElementById(id);
const WEEKS = 12, WEEK_SEC = 6, CAP = 6, TIME_KM = 7, TRASH_AGE = 4, NEED_WEEKS = 3, TRUCK_KMPS = 3.0, HOP_SEC = 1.6;
const C = { land: '#CFE8B4', city: '#E4F3D3', canada: '#C2E2A6', water: '#5BC0EB', wave: '#86D3F3', park: '#A9DA8B',
  road: '#FFFFFF', roadEdge: '#A9B9CA', fwy: '#FFEBB0', fwyEdge: '#E6C27A', lot: '#EDCF8E', lotEdge: '#B98F45',
  ink: '#1D2433', white: '#FFFFFF', good: '#12A150', bad: '#E63946', truck: '#FF8C42', truckDark: '#C8641F',
  drone: '#7B61FF', hidden: '#6B7280', ware: '#1C9C8D', cone: '#FF7A00', dump: '#8B8F98' };
const MATS = [
  { name: 'steel', color: '#8FA0B8', dark: '#5B6880' },
  { name: 'brick', color: '#EF6F6C', dark: '#B24340' },
  { name: 'wood', color: '#F4B942', dark: '#BF8318' },
];
const PL = [
  { name: 'Henry Ford', full: 'Henry Ford Hospital tower', lon: -83.0858, lat: 42.3666, slots: 12, rate: 1.4, mix: [.5, .25, .25], needRate: .34, needMix: [.5, .4, .1] },
  { name: 'The Claire', full: 'The Claire apartments', lon: -83.0846, lat: 42.3790, slots: 8, rate: .6, mix: [.1, .3, .6], needRate: .3, needMix: [.05, .35, .6] },
  { name: 'Midtown West', full: 'Midtown West homes', lon: -83.0722, lat: 42.3514, slots: 12, rate: 1.3, mix: [.15, .25, .6], needRate: .16, needMix: [.2, .3, .5] },
  { name: 'U-M Center', full: 'U-M Center for Innovation', lon: -83.0536, lat: 42.3377, slots: 12, rate: 1.0, mix: [.45, .35, .2], needRate: .32, needMix: [.5, .35, .15] },
  { name: 'JW Marriott', full: 'JW Marriott hotel', lon: -83.0530, lat: 42.3254, slots: 12, rate: 1.5, mix: [.35, .35, .3], needRate: .16, needMix: [.3, .4, .3] },
  { name: 'AlumniFi Field', full: 'AlumniFi Field stadium', lon: -83.0850, lat: 42.3315, slots: 12, rate: 1.2, mix: [.5, .4, .1], needRate: .26, needMix: [.55, .4, .05] },
  { name: 'Reuse Warehouse', full: 'Architectural Salvage Warehouse', lon: -83.0190, lat: 42.3688, slots: 18, warehouse: true },
];
const WH = PL.findIndex(p => p.warehouse);
const REAL_CLOSURE = { road: 'Michigan Ave', lon0: -83.0845, lon1: -83.0670, real: true };
const ROADWORK = [
  { road: 'W. Grand Blvd', lon0: -83.0990, lon1: -83.0870 }, { road: 'Grand River Ave', lon0: -83.0640, lon1: -83.0500 },
  { road: 'Woodward Ave', lon0: -83.0690, lon1: -83.0560 }, { road: 'Lodge Fwy', lon0: -83.0780, lon1: -83.0640 },
  { road: 'W. Jefferson Ave', lon0: -83.0700, lon1: -83.0520 }, { road: 'Gratiot Ave', lon0: -83.0450, lon1: -83.0280 },
];

// ---------- geometry ----------
const G = buildGraph(ROADS, PL.map(p => toKm(p.lon, p.lat)));
const KM = pts => pts.map(p => toKm(p[0], p[1]));
const WATER_KM = KM(SHORE_US.concat(SHORE_CA.slice().reverse())), CANADA_KM = KM(CANADA), BELLE_KM = KM(BELLE_ISLE), CITY_KM = KM(CITY);
const placeKm = i => toKm(PL[i].lon, PL[i].lat);
PL.forEach((p, i) => {
  const [ax, ay] = placeKm(i), an = G.anchorNode[i], best = new Map();
  for (let n = 0; n < G.N0; n++) { const d = Math.hypot(G.X[n] - ax, G.Y[n] - ay); if (d > 1.2) continue; const r = G.roadOf[n], cur = best.get(r); if (!cur || d < cur[0]) best.set(r, [d, n]); }
  [...best.values()].sort((x, y) => x[0] - y[0]).slice(0, 3).forEach(([d, n]) => { const w = d * 1.25 + 0.02; G.adj[an].push(n, w); G.adj[n].push(an, w); });
});
const pairKey = (a, b) => Math.min(a, b) + '-' + Math.max(a, b);
const straightKm = (a, b) => { const p = placeKm(a), q = placeKm(b); return Math.hypot(p[0] - q[0], p[1] - q[1]); };
function closureNodes(c) { const ri = ROADS.findIndex(r => r.n === c.road), x0 = toKm(c.lon0, 0)[0], x1 = toKm(c.lon1, 0)[0], out = []; for (let i = 0; i < G.N0; i++) if (G.roadOf[i] === ri && G.X[i] >= x0 && G.X[i] <= x1) out.push(i); return out; }
[REAL_CLOSURE].concat(ROADWORK).forEach(c => { c.nodes = closureNodes(c); });
const closuresNow = () => [REAL_CLOSURE].concat(S && S.roadwork ? [S.roadwork] : []);
function route(a, b) {
  const blocked = new Uint8Array(G.N); for (const c of closuresNow()) for (const n of c.nodes) blocked[n] = 1;
  const r = dijkstra(G.adj, G.N, G.anchorNode[a], blocked), end = G.anchorNode[b];
  if (!isFinite(r.dist[end])) return null;
  const nodes = []; let u = end; while (u >= 0) { nodes.push(u); if (u === G.anchorNode[a]) break; u = r.prev[u]; }
  nodes.reverse(); const flat = new Float32Array(nodes.length * 2);
  nodes.forEach((n, i) => { flat[2 * i] = G.X[n]; flat[2 * i + 1] = G.Y[n]; });
  return { flat, km: r.dist[end] };
}
function cumOf(f) { if (f._c) return f._c; const n = f.length / 2, c = new Float32Array(n); for (let i = 1; i < n; i++) c[i] = c[i - 1] + Math.hypot(f[2 * i] - f[2 * i - 2], f[2 * i + 1] - f[2 * i - 1]); f._c = c; return c; }
function pointAt(f, d) { const c = cumOf(f), n = c.length; d = Math.max(0, Math.min(d, c[n - 1])); let i = 1; while (i < n - 1 && c[i] < d) i++; const t = (d - c[i - 1]) / ((c[i] - c[i - 1]) || 1); return [f[2 * i - 2] + (f[2 * i] - f[2 * i - 2]) * t, f[2 * i - 1] + (f[2 * i + 1] - f[2 * i - 1]) * t, i]; }

// ---------- state ----------
let S = null, rng = Math.random;
const pickW = w => { let r = rng() * w.reduce((a, b) => a + b, 0); for (let i = 0; i < w.length; i++) { r -= w[i]; if (r <= 0) return i; } return w.length - 1; };
const poisson = l => { const L = Math.exp(-l); let k = 0, p = 1; do { k++; p *= rng(); } while (p > L); return k - 1; };
const now = () => performance.now() / 1000;
const droneOrder = [1, 0, 2, 3, 4, 5];

function newGame() {
  rng = mulberry32((Math.random() * 4294967295) >>> 0);
  S = { week: 1, acc: 0, started: false, over: false, paused: false, hold: false,
    places: PL.map(() => ({ crates: [], need: null })), used: 0, reused: 0, wasted: 0, boughtNew: 0, refused: 0, arrived: 0,
    lessons: [], lessonSet: new Set(), weekBlocked: new Set(), lastRefuse: 0, drone: { at: 0, next: 1, t0: now(), scanT: 0 }, truck: null, proposal: null,
    autopilot: false, pick: null, roadwork: null, autoT: 0 };
  PL.forEach((p, i) => {
    if (p.warehouse) return;
    const n = 3 + Math.floor(rng() * 4);
    for (let k = 0; k < n; k++) S.places[i].crates.push({ m: pickW(p.mix), age: Math.floor(rng() * 2), seen: false });
    S.arrived += n;
  });
  let posted = 0; for (const i of [0, 3, 1, 5]) if (posted < 2 && rng() < 0.75 && postNeed(i)) posted++;
  if (!posted) postNeed(0);
  fx = []; $('log').innerHTML = '';
  $('autopilot').checked = false;
  say('Hi! I\u2019m the AI dispatcher. The drone is scanning the yards so I can see the hidden crates. Press \u201cAsk the AI\u201d and I\u2019ll tell you where to send them.');
  setProposal(null); hint('Tap a yard, then tap where its crates should go. Or ask the AI.');
  $('endcard').hidden = true;
  render();
}
function postNeed(i) { const p = PL[i], st = S.places[i]; if (p.warehouse || st.need) return false; st.need = { m: pickW(p.needMix), q: 2 + Math.floor(rng() * 3), left: NEED_WEEKS }; return true; }
const saved = () => S.used + S.places[WH].crates.length;

function weekTick() {
  let trashed = 0;
  PL.forEach((p, i) => {
    if (p.warehouse) return; const st = S.places[i];
    st.crates.forEach(c => c.age++);
    const out = st.crates.filter(c => c.age >= TRASH_AGE);
    if (out.length) { st.crates = st.crates.filter(c => c.age < TRASH_AGE); trashed += out.length; S.wasted += out.length; out.forEach((c, k) => toDump(i, c.m, k)); pop(i, out.some(c => !c.seen) ? 'Thrown out unseen!' : 'Thrown out!', 'bad'); }
    if (st.need) { st.need.left--; if (st.need.left <= 0) { S.boughtNew++; pop(i, 'Had to buy new!', 'bad', 30); st.need = null; } }
  });
  const wh = S.places[WH], give = Math.min(3, wh.crates.length);
  if (give) { wh.crates.splice(0, give); S.used += give; S.reused += give; pop(WH, '+' + give + ' reused by neighbors!', 'good'); }
  S.week++;
  if (S.week > WEEKS) { S.week = WEEKS; endGame(); return; }
  PL.forEach((p, i) => {
    if (p.warehouse) return; const st = S.places[i], n = poisson(p.rate);
    for (let k = 0; k < n; k++) { S.arrived++; if (st.crates.length < p.slots) st.crates.push({ m: pickW(p.mix), age: 0, seen: false }); else { S.wasted++; toDump(i, pickW(p.mix), k); } }
  });
  PL.forEach((p, i) => { if (!p.warehouse && !S.places[i].need && rng() < p.needRate) postNeed(i); });
  S.weekBlocked.clear();
  S.roadwork = rng() < 0.5 ? ROADWORK[Math.floor(rng() * ROADWORK.length)] : null;
  logLine('sys', 'Week ' + S.week + ': new extra crates arrived, hidden until the drone scans them' + (trashed ? '. ' + trashed + ' old crate' + (trashed === 1 ? ' was' : 's were') + ' thrown out' : '') + (S.roadwork ? '. Road work on ' + S.roadwork.road + ' this week.' : '.'));
  render();
}
function endGame() {
  S.over = true; S.truck = null; setProposal(null);
  const total = saved() + S.wasted, pct = total ? saved() / total : 0, stars = pct >= 0.55 ? 3 : pct >= 0.35 ? 2 : pct >= 0.15 ? 1 : 0;
  $('stars').innerHTML = [0, 1, 2].map(k => '<span class="star' + (k < stars ? ' on' : '') + '">\u2605</span>').join('');
  $('endtext').textContent = 'You saved ' + saved() + ' crates: ' + (S.used - S.reused) + ' went straight to builders who needed them, ' + S.reused + ' were reused by neighbors from the Reuse Warehouse, and ' + S.places[WH].crates.length + ' are still stored there. ' + S.wasted + ' were thrown out.';
  $('endnote').textContent = 'Without the drones and the AI dispatcher, nobody would have seen any of the ' + S.arrived + ' extra crates, and every one would have gone to the landfill.';
  $('endcard').hidden = false; render();
}

// ---------- moves ----------
function refuse(kind, where, text, who, mvText, extra) {
  S.refused++; S.lastRefuse = now();
  const words = { heavy: 'Too heavy!', far: 'Too far!', notneeded: 'Not needed!', full: 'Full!', blind: 'Can\u2019t see them!', noroad: 'No road!' }[kind];
  fx.push(Object.assign({ kind, i: where, text: words, t0: now(), dur: 3.4 }, extra || {}));
  logLine('bad', (who === 'AI' ? 'AI' : 'You') + ': ' + mvText + '. ' + words + ' ' + text);
  if (who === 'AI') say(aiOops(kind, text)); else hint(words + ' ' + text);
  render();
}
function aiOops(kind, text) {
  if (kind === 'far') return 'Oops! I measured in a straight line, like on a map, but trucks have to follow the streets. ' + text + ' Lesson learned, I won\u2019t try that trip again.';
  if (kind === 'notneeded') return 'Oops! ' + text + ' The need changed while the truck was driving.';
  if (kind === 'noroad') return 'Oops! ' + text + ' I\u2019ll skip that trip until the road work is done.';
  return 'Oops! ' + text;
}
const mvText = (a, b, m, q) => q + ' ' + MATS[m].name + ' from ' + PL[a].name + ' to ' + PL[b].name;
function attempt(a, b, m, q, who) {
  if (!S.started || S.over) return;
  if (S.truck) { (who === 'AI' ? say : hint)('The robot truck is still out. Wait for it to come back!'); return; }
  const src = S.places[a], t = mvText(a, b, m, q);
  if (q > CAP) return refuse('heavy', a, 'A robot truck carries ' + CAP + ' crates, and this load was ' + q + '.', who, t, { q, m });
  const r = route(a, b);
  if (!r) { if (who === 'AI') S.weekBlocked.add(pairKey(a, b)); return refuse('noroad', a, 'Road work cuts off every street between ' + PL[a].name + ' and ' + PL[b].name + ' this week.', who, t); }
  const load = [];
  src.crates.sort((x, y) => x.age - y.age);
  for (let k = src.crates.length - 1; k >= 0 && load.length < q; k--) if (src.crates[k].m === m && src.crates[k].seen) { load.push(src.crates[k]); src.crates.splice(k, 1); }
  S.truck = { a, b, m, load, flat: r.flat, km: r.km, stopKm: Math.min(r.km, TIME_KM), t0: now(), who, text: t, done: false };
  if (who === 'AI') say('Sending ' + t + '. By street it\u2019s ' + r.km.toFixed(1) + ' km. Here we go!'); else hint('Robot truck on its way: ' + t + '.');
  render();
}
function bringBack(tr) { const st = S.places[tr.a], p = PL[tr.a]; for (const c of tr.load) { if (st.crates.length < p.slots) st.crates.push(c); else { S.wasted++; } } }
function arrive(tr) {
  const P = PL[tr.b], dst = S.places[tr.b], q = tr.load.length, mName = MATS[tr.m].name;
  if (tr.km > TIME_KM) {
    if (tr.who === 'AI') { const key = pairKey(tr.a, tr.b); if (!S.lessonSet.has(key)) { S.lessonSet.add(key); S.lessons.unshift(PL[tr.a].name + ' to ' + PL[tr.b].name + ' is too far by road (' + tr.km.toFixed(1) + ' km).'); } }
    const q0 = tr.load.length; bringBack(tr); tr.load = [];
    return refuse('far', null, 'The streets make that trip ' + tr.km.toFixed(1) + ' km, but a delivery has to arrive within ' + TIME_KM + ' km. The crates went back.', tr.who, tr.text, { at: pointAt(tr.flat, tr.stopKm), flat: tr.flat, from: tr.stopKm, m: tr.m, q: q0 });
  }
  if (P.warehouse) {
    const room = P.slots - dst.crates.length, take = Math.min(room, q);
    for (let k = 0; k < take; k++) { const c = tr.load.shift(); c.age = 0; dst.crates.push(c); }
    if (take) { fx.push({ kind: 'good', i: tr.b, text: '+' + take + ' saved!', t0: now(), dur: 2.4 }); confetti(tr.b); }
    if (take === q) { logLine('good', (tr.who === 'AI' ? 'AI' : 'You') + ': ' + tr.text + '. Stored for reuse!'); if (tr.who === 'AI') say('Stored ' + take + ' ' + mName + ' crates at the Reuse Warehouse. They\u2019re safe from the landfill now!'); else hint('Stored ' + take + ' crates. Safe!'); render(); return; }
    bringBack(tr);
    return refuse('full', tr.b, 'The Reuse Warehouse had room for ' + take + ', so ' + (q - take) + ' went back.', tr.who, tr.text, { q: q - take, m: tr.m });
  }
  if (dst.need && dst.need.m === tr.m) {
    const use = Math.min(q, dst.need.q); dst.need.q -= use; S.used += use; tr.load.splice(0, use);
    if (dst.need.q <= 0) dst.need = null;
    fx.push({ kind: 'good', i: tr.b, text: '+' + use + ' saved!', t0: now(), dur: 2.4 }); confetti(tr.b);
    if (tr.load.length) { const extra = tr.load.length; bringBack(tr); return refuse('notneeded', tr.b, PL[tr.b].name + ' used ' + use + ' and only needed that many, so ' + extra + ' went back.', tr.who, tr.text); }
    logLine('good', (tr.who === 'AI' ? 'AI' : 'You') + ': ' + tr.text + '. Delivered to a builder who needed it!');
    if (tr.who === 'AI') say('Delivered! ' + P.name + ' used ' + use + ' ' + mName + ' crates that would have been thrown away.'); else hint('Delivered! ' + use + ' crates put to use.');
    render(); return;
  }
  bringBack(tr);
  refuse('notneeded', tr.b, dst.need ? P.name + ' needs ' + MATS[dst.need.m].name + ', not ' + mName + '.' : P.name + ' doesn\u2019t need anything right now.', tr.who, tr.text);
}

// ---------- the AI dispatcher (built-in hypothesis) ----------
function aiSuggest() {
  const seenOf = (i, m) => S.places[i].crates.filter(c => c.seen && c.m === m).length;
  const cand = [];
  PL.forEach((t, ti) => {
    const need = S.places[ti].need; if (!need) return;
    PL.forEach((s, si) => {
      if (si === ti) return; const have = seenOf(si, need.m); if (!have) return;
      if (S.lessonSet.has(pairKey(si, ti)) || S.weekBlocked.has(pairKey(si, ti))) return;
      const km = straightKm(si, ti); if (km > TIME_KM) return;
      const q = Math.min(have, need.q, CAP);
      cand.push({ a: si, b: ti, m: need.m, q, km, kind: 'need', score: q * 10 - km * 2 + (NEED_WEEKS - need.left) * 8 });
    });
  });
  const room = PL[WH].slots - S.places[WH].crates.length;
  if (room > 0) PL.forEach((s, si) => {
    if (s.warehouse) return;
    const old = S.places[si].crates.filter(c => c.seen && c.age >= 2); if (!old.length) return;
    if (S.lessonSet.has(pairKey(si, WH)) || S.weekBlocked.has(pairKey(si, WH))) return;
    const counts = [0, 0, 0]; old.forEach(c => counts[c.m]++); const m = counts.indexOf(Math.max(...counts));
    const km = straightKm(si, WH); if (km > TIME_KM) return;
    const q = Math.min(counts[m], CAP, room);
    cand.push({ a: si, b: WH, m, q, km, kind: 'save', score: q * 7 - km * 2 + Math.max(...old.map(c => c.age)) * 4 });
  });
  cand.sort((x, y) => y.score - x.score);
  return cand[0] || null;
}
function aiSpeech(sg) {
  const mName = MATS[sg.m].name;
  if (sg.kind === 'need') return PL[sg.b].name + ' needs ' + S.places[sg.b].need.q + ' ' + mName + ' crates. I can see ' + (sg.q === S.places[sg.b].need.q ? '' : 'some ') + mName + ' crates sitting at ' + PL[sg.a].name + ', about ' + sg.km.toFixed(1) + ' km away. Send ' + sg.q + '?';
  return sg.q + ' ' + mName + ' crates at ' + PL[sg.a].name + ' are getting old and will be thrown out soon. Let\u2019s store them at the Reuse Warehouse, about ' + sg.km.toFixed(1) + ' km away!';
}
function aiNothing() {
  const hiddenCount = S.places.reduce((a, st) => a + st.crates.filter(c => !c.seen).length, 0);
  return hiddenCount ? 'I don\u2019t see a good move yet. ' + hiddenCount + ' crates are still hidden. The drone will scan them soon!' : 'Nothing to move right now. Every yard is under control!';
}
function askAI() {
  if (!S.started || S.over) return;
  if (S.truck) { say('The robot truck is still out. Ask me again when it\u2019s back!'); return; }
  const sg = aiSuggest();
  if (!sg) { say(aiNothing()); return; }
  setProposal(sg); say(aiSpeech(sg));
}
function setProposal(sg) {
  S && (S.proposal = sg); if (S) S.hold = !!sg && !S.autopilot;
  $('askbtns').hidden = !!sg; $('gobtns').hidden = !sg; $('mask').hidden = !!sg; $('mgo').hidden = !sg; $('mnope').hidden = !sg;
  render();
}
$('ask').addEventListener('click', askAI);
function goNow() { const sg = S.proposal; if (!sg) return; setProposal(null); attempt(sg.a, sg.b, sg.m, sg.q, 'AI'); }
function notNow() { setProposal(null); say('Okay! Ask me again whenever you want.'); }
$('go').addEventListener('click', goNow); $('nope').addEventListener('click', notNow);
$('mask').addEventListener('click', askAI); $('mgo').addEventListener('click', goNow); $('mnope').addEventListener('click', notNow);
$('autopilot').addEventListener('change', e => { S.autopilot = e.target.checked; if (S.autopilot) { setProposal(null); say('Autopilot on! I\u2019ll pick the moves and send the trucks myself. Watch the saved crates add up.'); } else say('Autopilot off. You\u2019re back in charge!'); });

// ---------- player taps ----------
function tapPlace(i) {
  if (!S.started || S.over) return;
  if (S.pick == null) {
    const st = S.places[i], seen = st.crates.filter(c => c.seen), hid = st.crates.length - seen.length;
    if (!st.crates.length) { hint(PL[i].name + ' has no extra crates right now.'); return; }
    S.pick = i;
    const counts = [0, 1, 2].map(m => seen.filter(c => c.m === m).length).map((n, m) => n ? n + ' ' + MATS[m].name : '').filter(Boolean).join(', ');
    hint('Picked ' + PL[i].name + (counts ? ': you can see ' + counts : ': all its crates are still hidden') + (hid ? ' (' + hid + ' hidden)' : '') + '. Now tap where to send them.');
    render(); return;
  }
  const a = S.pick; S.pick = null;
  if (a === i) { hint('Cancelled. Tap a yard to pick it.'); render(); return; }
  const src = S.places[a], seen = src.crates.filter(c => c.seen), need = S.places[i].need;
  if (!seen.length) return refuse('blind', a, 'Those crates haven\u2019t been scanned yet, so nobody knows what they are. Wait for the drone!', 'You', 'Crates from ' + PL[a].name + ' to ' + PL[i].name);
  let m;
  if (need && seen.some(c => c.m === need.m)) m = need.m;
  else { const counts = [0, 1, 2].map(mm => seen.filter(c => c.m === mm).length); m = counts.indexOf(Math.max(...counts)); }
  attempt(a, i, m, seen.filter(c => c.m === m).length, 'You');
}

// ---------- messages & log ----------
function say(t) { $('bubble').textContent = t; $('mbubble').textContent = t; }
function hint(t) { $('hint').textContent = t; }
function logLine(cls, t) {
  const li = document.createElement('li'); li.className = cls;
  li.textContent = (cls === 'sys' ? '' : 'Week ' + S.week + '. ') + t; $('log').prepend(li);
  while ($('log').children.length > 60) $('log').lastChild.remove();
}
function render() {
  if (!S) return;
  $('saved').textContent = saved(); $('wasted').textContent = S.wasted; $('refused').textContent = S.refused;
  $('weeklabel').textContent = 'Week ' + S.week + ' of ' + WEEKS;
  const bars = $('weekbar'); if (bars.children.length !== WEEKS) { bars.innerHTML = ''; for (let k = 0; k < WEEKS; k++) bars.appendChild(document.createElement('i')); }
  [...bars.children].forEach((el, k) => el.className = k < S.week - 1 ? 'done' : k === S.week - 1 ? 'now' : '');
  $('pause').textContent = S.paused ? 'Play' : 'Pause'; $('pause').disabled = !S.started || S.over;
  $('lessons').innerHTML = S.lessons.length ? S.lessons.slice(0, 4).map(l => '<li>' + l.replace(/&/g, '&amp;').replace(/</g, '&lt;') + '</li>').join('') : '<li class="empty">Nothing yet. Every refused trip teaches the AI something.</li>';
}
$('pause').addEventListener('click', () => { S.paused = !S.paused; render(); });
$('restart').addEventListener('click', () => { newGame(); S.started = true; $('startcard').hidden = true; });
$('play').addEventListener('click', () => { S.started = true; $('startcard').hidden = true; S.drone.t0 = now(); render(); });
$('again').addEventListener('click', () => { newGame(); S.started = true; });
// keyboard alternative
PL.forEach((p, i) => { for (const id of ['kfrom', 'kto']) { const o = document.createElement('option'); o.value = i; o.textContent = p.name; $(id).appendChild(o); } });
$('kto').value = WH;
$('ksend').addEventListener('click', () => { S.pick = null; tapPlace(+$('kfrom').value); tapPlace(+$('kto').value); });

// ---------- drawing ----------
const cv = $('board'), ctx = cv.getContext('2d'), wrap = $('boardwrap');
let W = 700, H = 560, DPR = 1, view = { cx: 0, cy: 0, s: 80 }, geo = [], fx = [], parts = [];
const EXT = [-83.0990, 42.3185, -83.0110, 42.3850];
function size() {
  const r = wrap.getBoundingClientRect(); W = Math.max(280, Math.floor(r.width));
  H = Math.round(Math.min(700, Math.max(420, W * (W < 640 ? 1.25 : 0.74))));
  DPR = Math.min(2, window.devicePixelRatio || 1); cv.width = Math.round(W * DPR); cv.height = Math.round(H * DPR); cv.style.height = H + 'px';
  const a = toKm(EXT[0], EXT[1]), b = toKm(EXT[2], EXT[3]);
  view.cx = (a[0] + b[0]) / 2; view.cy = (a[1] + b[1]) / 2 - (W < 640 ? 0 : 0.15); view.s = Math.min(W / (b[0] - a[0]), H / (b[1] - a[1]));
}
const SX = x => (x - view.cx) * view.s + W / 2, SY = y => H / 2 - (y - view.cy) * view.s;
const font = (s, w) => { ctx.font = (w || 400) + ' ' + s + 'px "Lilita One", "Arial Black", Impact, sans-serif'; };
const ui = (s, w) => { ctx.font = (w || 700) + ' ' + s + 'px Nunito, "Trebuchet MS", Arial, sans-serif'; };
function poly(pts, close) { ctx.beginPath(); pts.forEach((p, i) => i ? ctx.lineTo(SX(p[0]), SY(p[1])) : ctx.moveTo(SX(p[0]), SY(p[1]))); if (close) ctx.closePath(); }
function rr(x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
function outlined(t, x, y, fill, lw) { ctx.lineJoin = 'round'; ctx.lineWidth = lw || 5; ctx.strokeStyle = C.white; ctx.strokeText(t, x, y); ctx.fillStyle = fill; ctx.fillText(t, x, y); }
function flatPath(f, from, to) { const c = cumOf(f), n = c.length; ctx.beginPath(); const s = pointAt(f, from); ctx.moveTo(SX(s[0]), SY(s[1])); for (let i = s[2]; i < n; i++) { if (c[i] >= to) break; ctx.lineTo(SX(f[2 * i]), SY(f[2 * i + 1])); } const e = pointAt(f, to); ctx.lineTo(SX(e[0]), SY(e[1])); }
function crate(x, y, s, m, hidden, warn, t) {
  const wob = warn ? Math.sin(t * 14 + x) * 1.2 : 0;
  x += wob;
  if (hidden) { ctx.fillStyle = C.hidden; rr(x, y, s, s, 2.5); ctx.fill(); ctx.fillStyle = C.white; font(s * 0.78); ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('?', x + s / 2, y + s / 2 + 1); }
  else {
    const M = MATS[m]; ctx.fillStyle = M.color; rr(x, y, s, s, 2.5); ctx.fill();
    ctx.fillStyle = M.dark; ctx.fillRect(x + 1, y + s * 0.68, s - 2, s * 0.24);
    ctx.strokeStyle = M.dark; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(x + s * 0.2, y + s * 0.2); ctx.lineTo(x + s * 0.8, y + s * 0.62); ctx.stroke();
  }
  if (warn) { ctx.strokeStyle = C.bad; ctx.lineWidth = 2; rr(x - 1, y - 1, s + 2, s + 2, 3); ctx.stroke(); }
}
function crane(x, y, s) {
  ctx.strokeStyle = '#E8A317'; ctx.lineWidth = Math.max(1.5, s * 0.12); ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, y - s * 2.2); ctx.lineTo(x + s * 1.8, y - s * 2.2); ctx.moveTo(x, y - s * 2.2); ctx.lineTo(x - s * 0.6, y - s * 2.2); ctx.stroke();
  ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(x + s * 1.5, y - s * 2.2); ctx.lineTo(x + s * 1.5, y - s * 1.4); ctx.stroke();
}
function drawTruck(x, y, ang, m, q, frac, tipped) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(ang + (tipped || 0));
  if (frac != null) { ctx.strokeStyle = 'rgba(255,255,255,.9)'; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(0, 0, 19, 0, 7); ctx.stroke();
    ctx.strokeStyle = frac > 0.85 ? C.bad : C.good; ctx.beginPath(); ctx.arc(0, 0, 19, -Math.PI / 2, -Math.PI / 2 + Math.min(1, frac) * Math.PI * 2); ctx.stroke(); }
  ctx.fillStyle = 'rgba(0,0,0,.18)'; rr(-13, -6, 28, 14, 3); ctx.fill();
  ctx.fillStyle = C.truck; rr(-14, -8, 20, 15, 3); ctx.fill();
  ctx.fillStyle = C.truckDark; rr(6, -7, 9, 13, 3); ctx.fill();
  ctx.fillStyle = '#BFE6FF'; ctx.fillRect(10, -5, 4, 9);
  const n = Math.min(q, 9);
  for (let k = 0; k < n; k++) { const cx = -12 + (k % 3) * 6, cy = -6 + Math.floor(k / 3) * 5 - (k >= 6 ? 12 : 0); ctx.fillStyle = MATS[m].color; ctx.fillRect(cx, cy, 5, 4.5); ctx.strokeStyle = k >= CAP ? C.bad : MATS[m].dark; ctx.lineWidth = k >= CAP ? 1.5 : .8; ctx.strokeRect(cx, cy, 5, 4.5); }
  ctx.restore();
}
function drawDrone(x, y, t, scanning) {
  if (scanning) { ctx.fillStyle = 'rgba(123,97,255,.18)'; ctx.beginPath(); ctx.moveTo(x, y + 4); ctx.lineTo(x - 26, y + 40); ctx.lineTo(x + 26, y + 40); ctx.closePath(); ctx.fill(); }
  ctx.fillStyle = 'rgba(0,0,0,.15)'; ctx.beginPath(); ctx.ellipse(x + 6, y + 16, 12, 4, 0, 0, 7); ctx.fill();
  ctx.strokeStyle = C.drone; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.moveTo(x - 9, y - 9); ctx.lineTo(x + 9, y + 9); ctx.moveTo(x + 9, y - 9); ctx.lineTo(x - 9, y + 9); ctx.stroke();
  for (const [dx, dy] of [[-9, -9], [9, -9], [-9, 9], [9, 9]]) { ctx.strokeStyle = 'rgba(123,97,255,.55)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(x + dx, y + dy, 5.5, t * 20, t * 20 + 2.2); ctx.stroke(); ctx.beginPath(); ctx.arc(x + dx, y + dy, 5.5, t * 20 + Math.PI, t * 20 + Math.PI + 2.2); ctx.stroke(); }
  ctx.fillStyle = C.drone; rr(x - 5.5, y - 5.5, 11, 11, 3); ctx.fill(); ctx.fillStyle = C.white; ctx.beginPath(); ctx.arc(x, y, 2.2, 0, 7); ctx.fill();
}
function drawCone(x, y, s) { ctx.fillStyle = C.cone; ctx.beginPath(); ctx.moveTo(x, y - s); ctx.lineTo(x + s * 0.55, y + s * 0.4); ctx.lineTo(x - s * 0.55, y + s * 0.4); ctx.closePath(); ctx.fill(); ctx.fillStyle = C.white; ctx.fillRect(x - s * 0.3, y - s * 0.25, s * 0.6, s * 0.18); ctx.fillStyle = '#C45A00'; ctx.fillRect(x - s * 0.7, y + s * 0.4, s * 1.4, s * 0.2); }
function dumpXY() { return [W - 58, H - 44]; }
function toDump(i, m, k) { fx.push({ kind: 'trash', i, m, t0: now() + k * 0.12, dur: 1.2 }); }
function pop(i, text, kind, dy) { fx.push({ kind: kind === 'bad' ? 'popbad' : 'popgood', i, text, dy: dy || 0, t0: now(), dur: 2.6 }); }
function confetti(i) { const g = geo[i]; if (!g) return; for (let k = 0; k < 18; k++) parts.push({ x: g.cx, y: g.ly, vx: (Math.random() - 0.5) * 160, vy: -Math.random() * 160 - 40, c: [C.good, '#FFD670', C.drone, '#5BC0EB', C.truck][k % 5], t0: now(), life: 1.1 }); }

function draw(t) {
  ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
  ctx.fillStyle = C.land; ctx.fillRect(0, 0, W, H);
  poly(CANADA_KM, true); ctx.fillStyle = C.canada; ctx.fill();
  poly(WATER_KM, true); ctx.fillStyle = C.water; ctx.fill();
  ctx.save(); poly(WATER_KM, true); ctx.clip(); ctx.strokeStyle = C.wave; ctx.lineWidth = 2;
  for (let k = 0; k < 40; k++) { const x = ((k * 97) % W) + Math.sin(t + k) * 6, y = ((k * 53) % H); ctx.beginPath(); ctx.arc(x, y, 6, Math.PI * 1.1, Math.PI * 1.9); ctx.stroke(); }
  ctx.restore();
  poly(CITY_KM, true); ctx.fillStyle = C.city; ctx.fill();
  poly(BELLE_KM, true); ctx.fillStyle = C.park; ctx.fill();
  ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  const rw = Math.max(3, view.s * 0.05);
  for (const r of G.roadsKm) if (r.k === 'art') { poly(r.km); ctx.strokeStyle = C.roadEdge; ctx.lineWidth = rw + 2.5; ctx.stroke(); }
  for (const r of G.roadsKm) if (r.k === 'art') { poly(r.km); ctx.strokeStyle = C.road; ctx.lineWidth = rw; ctx.stroke(); }
  for (const r of G.roadsKm) if (r.k === 'fwy') { poly(r.km); ctx.strokeStyle = C.fwyEdge; ctx.lineWidth = rw * 1.3 + 2.5; ctx.stroke(); ctx.strokeStyle = C.fwy; ctx.lineWidth = rw * 1.3; ctx.stroke(); }
  font(15); ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  { const p = toKm(-83.0350, 42.3222); ctx.save(); ctx.translate(SX(p[0]), SY(p[1])); ctx.rotate(-0.42); outlined('Detroit River', 0, 0, '#1B6FA0', 4); ctx.restore(); }
  if (W >= 640) { const p = toKm(-83.0300, 42.3155); ui(12, 800); outlined('Canada', SX(p[0]), SY(p[1]), '#4F7A34', 4); }
  // closures: barrier stripes and cones
  for (const c of closuresNow()) {
    if (c.nodes.length < 2) continue;
    ctx.beginPath(); c.nodes.forEach((n, i) => { const x = SX(G.X[n]), y = SY(G.Y[n]); i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); });
    ctx.strokeStyle = C.white; ctx.lineWidth = rw + 4; ctx.stroke(); ctx.strokeStyle = C.cone; ctx.setLineDash([7, 6]); ctx.stroke(); ctx.setLineDash([]);
    for (const n of [c.nodes[0], c.nodes[c.nodes.length - 1]]) drawCone(SX(G.X[n]), SY(G.Y[n]) - 2, 9);
    const mid = c.nodes[Math.floor(c.nodes.length / 2)]; ui(11, 900); ctx.textAlign = 'center'; outlined('Road closed', SX(G.X[mid]), SY(G.Y[mid]) + 16, C.cone, 4);
  }
  // landfill
  { const [dx, dy] = dumpXY(); ctx.fillStyle = C.dump; ctx.beginPath(); ctx.ellipse(dx, dy + 14, 42, 16, 0, Math.PI, 0); ctx.fill();
    ctx.fillStyle = '#6E727B'; for (let k = 0; k < Math.min(14, Math.ceil(S.wasted / 3)); k++) ctx.fillRect(dx - 30 + (k * 13) % 56, dy + 2 - Math.floor(k / 5) * 6, 8, 6);
    ui(11, 900); ctx.textAlign = 'center'; outlined('Landfill: ' + S.wasted, dx, dy + 26, C.bad, 4); }
  // yards
  const cell = Math.max(9, Math.min(15, view.s * 0.16)), gap = 2;
  geo = [];
  PL.forEach((p, i) => {
    const st = S.places[i], [kx, ky] = placeKm(i), cx = SX(kx), cy = SY(ky);
    const cols = p.warehouse ? 6 : 4, rows = Math.ceil(p.slots / cols), lw = cols * (cell + gap) + 8, lh = rows * (cell + gap) + 8;
    const lx = Math.max(6, Math.min(W - lw - 6, cx - lw / 2)), ly = Math.max(30, Math.min(H - lh - 6, cy - lh / 2));
    geo[i] = { cx: lx + lw / 2, cy: ly + lh / 2, lx, ly, lw, lh };
    const picked = S.pick === i, prop = S.proposal && (S.proposal.a === i || S.proposal.b === i);
    if (picked || prop) { ctx.strokeStyle = picked ? '#FFB703' : C.drone; ctx.lineWidth = 4; ctx.setLineDash([6, 4]); rr(lx - 5, ly - 5, lw + 10, lh + 10, 10); ctx.stroke(); ctx.setLineDash([]); }
    ctx.fillStyle = 'rgba(0,0,0,.12)'; rr(lx + 3, ly + 4, lw, lh, 8); ctx.fill();
    if (p.warehouse) {
      ctx.fillStyle = C.ware; rr(lx, ly, lw, lh, 8); ctx.fill(); ctx.fillStyle = '#E9FBF8'; rr(lx + 3, ly + 3, lw - 6, lh - 6, 6); ctx.fill();
      ctx.fillStyle = C.ware; ctx.beginPath(); ctx.moveTo(lx - 4, ly + 2); ctx.lineTo(lx + lw / 2, ly - 14); ctx.lineTo(lx + lw + 4, ly + 2); ctx.closePath(); ctx.fill();
    } else { ctx.fillStyle = C.lot; rr(lx, ly, lw, lh, 8); ctx.fill(); ctx.strokeStyle = C.lotEdge; ctx.lineWidth = 2; ctx.stroke(); crane(lx + lw - 6, ly + 2, cell * 0.5); }
    for (let k = 0; k < p.slots; k++) {
      const x = lx + 4 + (k % cols) * (cell + gap), y = ly + 4 + Math.floor(k / cols) * (cell + gap), c = st.crates[k];
      if (c) crate(x, y, cell, c.m, !c.seen && !p.warehouse, !p.warehouse && c.age >= TRASH_AGE - 1, t);
      else { ctx.strokeStyle = p.warehouse ? 'rgba(28,156,141,.35)' : 'rgba(120,85,30,.3)'; ctx.lineWidth = 1; rr(x + 0.5, y + 0.5, cell - 1, cell - 1, 2); ctx.stroke(); }
    }
    // name sign
    ui(W < 640 ? 11 : 12.5, 900); const tw = ctx.measureText(p.name).width + 14, sx = Math.max(4, Math.min(W - tw - 4, lx + lw / 2 - tw / 2)), sy = ly - (p.warehouse ? 34 : 24);
    ctx.fillStyle = p.warehouse ? C.ware : C.ink; rr(sx, sy, tw, 19, 9); ctx.fill(); ctx.fillStyle = C.white; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillText(p.name, sx + 7, sy + 10);
    // need bubble
    if (st.need) {
      const n = st.need, txt = 'Needs ' + n.q; ui(W < 640 ? 11 : 12.5, 900);
      const bw = ctx.measureText(txt).width + cell + 26, bh = 22 + 8;
      let bx = lx + lw + 10; if (bx + bw > W - 4) bx = lx - bw - 10;
      const by = ly + lh / 2 - bh / 2;
      ctx.fillStyle = n.left <= 1 ? '#FFE3E5' : C.white; ctx.strokeStyle = n.left <= 1 ? C.bad : C.ink; ctx.lineWidth = 2;
      rr(bx, by, bw, bh, 8); ctx.fill(); ctx.stroke();
      const px = bx > lx ? bx : bx + bw; ctx.fillStyle = n.left <= 1 ? '#FFE3E5' : C.white; ctx.beginPath(); ctx.moveTo(px, by + bh / 2 - 5); ctx.lineTo(px + (bx > lx ? -8 : 8), by + bh / 2); ctx.lineTo(px, by + bh / 2 + 5); ctx.closePath(); ctx.fill();
      ctx.fillStyle = C.ink; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillText(txt, bx + 8, by + 11);
      crate(bx + bw - cell - 8, by + 4, cell * 0.9, n.m, false, false, t);
      for (let k = 0; k < NEED_WEEKS; k++) { ctx.fillStyle = k < n.left ? (n.left <= 1 ? C.bad : C.ink) : 'rgba(0,0,0,.15)'; ctx.beginPath(); ctx.arc(bx + 12 + k * 9, by + bh - 6, 3, 0, 7); ctx.fill(); }
    }
  });
  // proposal line: the AI's straight-line guess
  if (S.proposal) {
    const A = geo[S.proposal.a], B = geo[S.proposal.b];
    ctx.strokeStyle = C.drone; ctx.lineWidth = 3; ctx.setLineDash([8, 6]); ctx.lineDashOffset = -t * 30;
    ctx.beginPath(); ctx.moveTo(A.cx, A.cy); ctx.lineTo(B.cx, B.cy); ctx.stroke(); ctx.setLineDash([]); ctx.lineDashOffset = 0;
    const ang = Math.atan2(B.cy - A.cy, B.cx - A.cx), ex = B.cx - Math.cos(ang) * (B.lw / 2 + 6), ey = B.cy - Math.sin(ang) * (B.lh / 2 + 6);
    ctx.fillStyle = C.drone; ctx.beginPath(); ctx.moveTo(ex, ey); ctx.lineTo(ex - Math.cos(ang) * 14 - Math.sin(ang) * 7, ey - Math.sin(ang) * 14 + Math.cos(ang) * 7); ctx.lineTo(ex - Math.cos(ang) * 14 + Math.sin(ang) * 7, ey - Math.sin(ang) * 14 - Math.cos(ang) * 7); ctx.fill();
    ui(12, 900); ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; outlined('AI\u2019s guess: ' + S.proposal.km.toFixed(1) + ' km', (A.cx + B.cx) / 2, (A.cy + B.cy) / 2 - 12, C.drone, 4);
  }
  // truck
  if (S.truck) {
    const tr = S.truck, d = Math.min(tr.stopKm, (t - tr.t0) * TRUCK_KMPS);
    ctx.strokeStyle = C.truck; ctx.lineWidth = 4; ctx.globalAlpha = 0.3; flatPath(tr.flat, 0, tr.km); ctx.stroke(); ctx.globalAlpha = 1; ctx.lineWidth = 5; flatPath(tr.flat, 0, d); ctx.stroke();
    const p = pointAt(tr.flat, d), p2 = pointAt(tr.flat, Math.min(d + 0.05, tr.km)), ang = Math.atan2(-(p2[1] - p[1]), p2[0] - p[0]);
    drawTruck(SX(p[0]), SY(p[1]), isFinite(ang) ? ang : 0, tr.m, tr.load.length, d / TIME_KM);
    if (d >= tr.stopKm && !tr.done && S.started) { tr.done = true; setTimeout(() => { if (S.truck === tr) { S.truck = null; arrive(tr); } }, 300); }
  }
  // drone
  if (S.started && !S.over) {
    const dr = S.drone, a = droneOrder[dr.at], b = droneOrder[dr.next], A = geo[a], B = geo[b];
    const u = Math.min(1, (t - dr.t0) / HOP_SEC), e = u < 0.5 ? 2 * u * u : 1 - Math.pow(-2 * u + 2, 2) / 2;
    const x = A.cx + (B.cx - A.cx) * e, y = (A.ly - 30) + ((B.ly - 30) - (A.ly - 30)) * e + Math.sin(t * 5) * 2;
    drawDrone(x, y, t, u >= 1);
  }
  // effects
  fx = fx.filter(f => t < f.t0 + f.dur);
  for (const f of fx) {
    if (t < f.t0) continue;
    const u = (t - f.t0) / f.dur, g = f.i != null ? geo[f.i] : null, alpha = Math.min(1, (1 - u) * 3);
    ctx.globalAlpha = alpha;
    if (f.kind === 'trash' && g) {
      const [dx, dy] = dumpXY(), x = g.cx + (dx - g.cx) * u, y = g.cy + (dy - g.cy) * u - Math.sin(u * Math.PI) * 60;
      ctx.save(); ctx.translate(x, y); ctx.rotate(u * 8); crate(-6, -6, 12, f.m, false, false, t); ctx.restore();
    } else if (f.kind === 'popgood' || f.kind === 'popbad' || f.kind === 'good') {
      const bad = f.kind === 'popbad', sc = Math.min(1, u * 8);
      font(bad ? 15 : 20); ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      const py = bad ? g.ly + g.lh + 14 + f.dy * 0.6 + u * 10 : Math.max(20, g.ly - 44 - f.dy - u * 18);
      ctx.save(); ctx.translate(Math.max(70, Math.min(W - 70, g.cx)), Math.min(H - 12, py)); ctx.scale(sc, sc); outlined(f.text, 0, 0, bad ? C.bad : C.good, 5); ctx.restore();
    } else {
      // refusals, drawn where they happened
      let x, y;
      if (f.kind === 'far') { x = SX(f.at[0]); y = SY(f.at[1]);
        ctx.strokeStyle = C.truck; ctx.lineWidth = 5; flatPath(f.flat, 0, f.from); ctx.stroke();
        drawTruck(x - 24, y + 4, 0, f.m != null ? f.m : 0, f.q || 0, null);
        ctx.strokeStyle = C.ink; ctx.lineWidth = 4; ctx.setLineDash([4, 6]); flatPath(f.flat, f.from, cumOf(f.flat)[cumOf(f.flat).length - 1]); ctx.stroke(); ctx.setLineDash([]);
        ctx.fillStyle = C.white; ctx.strokeStyle = C.bad; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(x, y, 16, 0, 7); ctx.fill(); ctx.stroke();
        ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, y - 10); ctx.moveTo(x, y); ctx.lineTo(x + 7, y + 3); ctx.stroke(); y -= 26;
      } else if (f.kind === 'heavy') { x = g.cx; y = g.cy; drawTruck(x + g.lw / 2 + 22, y + 12, 0, f.m, f.q, null, -0.35 * Math.min(1, u * 4) + Math.sin(t * 30) * 0.03 * (1 - u)); y = g.ly - 44; }
      else if (f.kind === 'notneeded' || f.kind === 'noroad') { x = g.cx; y = g.cy; ctx.strokeStyle = C.bad; ctx.lineWidth = 7; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(x - 16, y - 16); ctx.lineTo(x + 16, y + 16); ctx.moveTo(x + 16, y - 16); ctx.lineTo(x - 16, y + 16); ctx.stroke(); y = g.ly - 44; }
      else if (f.kind === 'full') { x = g.cx; y = g.cy; for (let k = 0; k < f.q; k++) crate(g.lx + g.lw + 6 + (k % 3) * 13, g.ly + g.lh - 12 - Math.floor(k / 3) * 13 - Math.abs(Math.sin(t * 8 + k)) * 6, 11, f.m, false, true, t); y = g.ly - 50; }
      else if (f.kind === 'blind') { x = g.cx; y = g.cy; ctx.fillStyle = 'rgba(107,114,128,.85)'; for (let k = 0; k < 5; k++) { ctx.beginPath(); ctx.arc(x - 24 + k * 12, y + Math.sin(t * 6 + k) * 3, 12, 0, 7); ctx.fill(); } font(24); ctx.fillStyle = C.white; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('?', x, y + 1); y = g.ly - 44; }
      const sc = Math.min(1, u * 10); font(W < 640 ? 21 : 26); ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.save(); ctx.translate(Math.max(80, Math.min(W - 80, x)), Math.max(24, Math.min(H - 20, y - u * 10))); ctx.scale(sc, sc); outlined(f.text, 0, 0, C.bad, 7); ctx.restore();
    }
    ctx.globalAlpha = 1;
  }
  parts = parts.filter(p => t < p.t0 + p.life);
  for (const p of parts) { const u = t - p.t0; ctx.fillStyle = p.c; ctx.globalAlpha = 1 - u / p.life; ctx.fillRect(p.x + p.vx * u, p.y + p.vy * u + 220 * u * u, 5, 5); }
  ctx.globalAlpha = 1;
}

// ---------- input ----------
cv.addEventListener('pointerup', e => {
  const r = cv.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top;
  const i = geo.findIndex(g => g && x >= g.lx - 8 && x <= g.lx + g.lw + 8 && y >= g.ly - 30 && y <= g.ly + g.lh + 8);
  if (i >= 0) tapPlace(i); else if (S.pick != null) { S.pick = null; hint('Cancelled. Tap a yard to pick it.'); render(); }
});

// ---------- loop ----------
let lastT = 0;
function frame(ms) {
  const t = ms / 1000, dt = lastT ? Math.min(0.2, t - lastT) : 0; lastT = t;
  if (S.started && !S.over && !S.paused) {
    if (!S.hold) { S.acc += dt; if (S.acc >= WEEK_SEC) { S.acc -= WEEK_SEC; weekTick(); } }
    const dr = S.drone; if (t - dr.t0 >= HOP_SEC + 0.7) { const i = droneOrder[dr.next]; S.places[i].crates.forEach(c => c.seen = true); fx.push({ kind: 'popgood', i, text: 'Scanned!', dy: -6, t0: t, dur: 1.2 }); dr.at = dr.next; dr.next = (dr.next + 1) % droneOrder.length; dr.t0 = t; }
    if (S.autopilot && !S.truck && !S.proposal && t - S.lastRefuse > 2.5) { S.autoT += dt; if (S.autoT > 1.0) { S.autoT = 0; const sg = aiSuggest(); if (sg) { say(aiSpeech(sg)); attempt(sg.a, sg.b, sg.m, sg.q, 'AI'); } } }
    $('clockfill').style.width = Math.min(100, S.acc / WEEK_SEC * 100) + '%';
  }
  draw(t); requestAnimationFrame(frame);
}
size(); newGame();
new ResizeObserver(size).observe(wrap);
requestAnimationFrame(frame);
})();
